graphics.off()
rm(list=ls())

whatwewant=function(x_intra,x_inter,val_signif,x_comp,x_fw,size_comp,size_fw){ 
#If available, val_signif is the vector containing only significant variables while x_inter contains all. Otherwise, x_inter contains the only coeff given, i.e. the significant ones
#x_comp are the competitive interactions, x_fw are the trophic interactions. 
	val_neg=sum(x_inter<0)
	adim=length(x_intra)
	if(is.na(val_signif)){
		prop_signif=length(x_inter)/(length(x_intra))^2
		val_signif=c(x_inter,rep(0,length(x_intra)^2-length(x_inter)))
	}else{
		prop_signif=length(val_signif)/(length(x_intra))^2
	}
	if(!is.na(x_comp)&!is.na(x_fw)){
		if((length(x_comp)+length(x_fw))!=length(x_inter)){
			print("error")
		}
	val_comp=sum(abs(x_comp))/size_comp
	val_fw=sum(abs(x_fw))/size_fw
	}else{
	val_comp=NA
	val_fw=NA
	}
	val=c(mean(abs(x_intra)),sd(abs(x_intra)),mean(abs(x_inter)),sd(abs(x_inter)),mean(abs(val_signif)),sd(abs(val_signif)),val_neg/adim^2,prop_signif,adim,val_comp,sd(abs(x_comp)),val_fw,sd(abs(x_fw)))
}


tab_answer=matrix(NA,nrow=1,ncol=14)

#Klug 2000
#Phytoplankton
tab_answer[1,1]='Klug2000_Phyto'
x_intra=c(0.3561,0.7738)-1
x_inter=c(-.12)
val_signif=NA
x_comp=x_inter
x_fw=NA
size_comp=NA
size_fw=NA
tab_answer[1,2:14]=whatwewant(x_intra,x_inter,val_signif,x_comp,x_fw,size_comp,size_fw)
#Zooplankton
code_name='Klug2000_Zoo'
x_intra=c(0.7609,0.6444,0.6886)-1
x_inter=c(-.41)
val_signif=NA
x_comp=x_inter
x_fw=NA
size_comp=NA
size_fw=NA
print(code_name)
tab_answer=rbind(tab_answer,c(code_name,whatwewant(x_intra,x_inter,val_signif,x_comp,x_fw,size_comp,size_fw)))

#Klug 2001
#Taxonomic algae
code_name='Klug2001_TaxoAlgae'
x_intra=c(-0.42,-0.43,-0.58,-0.46,-0.36)
x_inter=c(-0.05,-0.09,-0.23,-0.6,-0.18,-0.03)
val_signif=NA
x_comp=x_inter
x_fw=NA
size_comp=NA
size_fw=NA
print(code_name)
tab_answer=rbind(tab_answer,c(code_name,whatwewant(x_intra,x_inter,val_signif,x_comp,x_fw,size_comp,size_fw)))

#Morphological algae
code_name='Klug2001_MorphoAlgae'
x_intra=c(-0.41,-0.72,-0.58,-0.54)
x_inter=c(-0.14,-0.19)
val_signif=NA
x_comp=x_inter
x_fw=NA
size_comp=NA
size_fw=NA
print(code_name)
tab_answer=rbind(tab_answer,c(code_name,whatwewant(x_intra,x_inter,val_signif,x_comp,x_fw,size_comp,size_fw)))

#Ives 2003
#reference lake 
code_name='Ives2003_Plank1'
x_intra=c(0.5,0.61,0.76,0.56)-1
x_inter=c(0.1,-0.019,0,0)
val_signif=NA
x_comp=c(0,0)
x_fw=c(0.1,-0.019)
size_comp=4
size_fw=8
print(code_name)
tab_answer=rbind(tab_answer,c(code_name,whatwewant(x_intra,x_inter,val_signif,x_comp,x_fw,size_comp,size_fw)))
#high plnktivory lake
code_name='Ives2003_Plank2'
x_intra=c(0.5,0.61,0.95,0.56)-1
x_inter=c(-0.077,0.33,0.1,-0.019,0,0)
val_signif=NA
x_comp=c(-0.077,0,0)
x_fw=c(0.1,-0.019,0.33)
size_comp=4
size_fw=8
print(code_name)
tab_answer=rbind(tab_answer,c(code_name,whatwewant(x_intra,x_inter,val_signif,x_comp,x_fw,size_comp,size_fw)))
#Low planktivory
code_name='Ives2003_Plank3'
x_intra=c(0.5,0.072,0.76,0.56)-1
x_inter=c(-0.36,0.1,-0.019,-0.1,0,0)
val_signif=NA
x_comp=c(-0.36,0,0)
x_fw=c(-0.019,0.1,-0.1)
size_comp=4
size_fw=8
print(code_name)
tab_answer=rbind(tab_answer,c(code_name,whatwewant(x_intra,x_inter,val_signif,x_comp,x_fw,size_comp,size_fw)))

#Hampton 2006 is always about Lake Washington, so I'm gonna use only the biweekly in paper(a), in which we have the highest number of interaction parameters; and the monthly one in paper(b) (...because it is the only one we have)
#Hampton 2006a
if(1==0){
code_name='Hampton2006a_weekly'
plou=as.matrix(read.csv(paste(code_name,'.csv',sep=""),sep=";",dec=".",header=T,row.names=1))
x_intra=diag(plou)-1
nodiag=plou
diag(nodiag)=NA
nodiag=c(nodiag)
nodiag=nodiag[!is.na(nodiag)]
x_inter=nodiag
val_signif=NA
x_comp=NA
x_fw=NA
size_comp=NA
size_fw=NA
print(code_name)
tab_answer=rbind(tab_answer,c(code_name,whatwewant(x_intra,x_inter,val_signif,x_comp,x_fw,size_comp,size_fw)))
#Monthly
code_name='Hampton2006a_monthly'
plou=as.matrix(read.csv(paste(code_name,'.csv',sep=''),sep=";",dec=".",header=T,row.names=1))
x_intra=diag(plou)-1
nodiag=plou
diag(nodiag)=NA
nodiag=c(nodiag)
nodiag=nodiag[!is.na(nodiag)]
x_inter=nodiag
val_signif=NA
x_comp=NA
x_fw=NA
size_comp=NA
size_fw=NA
print(code_name)
tab_answer=rbind(tab_answer,c(code_name,whatwewant(x_intra,x_inter,val_signif,x_comp,x_fw,size_comp,size_fw)))


##########################################WARNING AUTOCORRELATION COEFFICIENT
#BiWeekly
code_name='Hampton2006a_biweekly'
plou=as.matrix(read.csv(paste(code_name,'.csv',sep=""),sep=";",dec=".",header=T,row.names=1))
x_intra=diag(plou)-1
nodiag=plou
diag(nodiag)=NA
nodiag=c(nodiag)
nodiag=nodiag[!is.na(nodiag)]
x_inter=nodiag
val_signif=NA
x_comp=NA
x_fw=NA
size_comp=NA
size_fw=NA
print(code_name)
tab_answer=rbind(tab_answer,c(code_name,whatwewant(x_intra,x_inter,val_signif,x_comp,x_fw,size_comp,size_fw)))

code_name='Hampton2006a_growing'
plou=as.matrix(read.csv(paste(code_name,'.csv',sep=""),sep=";",dec=".",header=T,row.names=1))
x_intra=diag(plou)-1
nodiag=plou
diag(nodiag)=NA
nodiag=c(nodiag)
nodiag=nodiag[!is.na(nodiag)]
x_inter=nodiag
val_signif=NA
x_comp=NA
x_fw=NA
size_comp=NA
size_fw=NA
print(code_name)
tab_answer=rbind(tab_answer,c(code_name,whatwewant(x_intra,x_inter,val_signif,x_comp,x_fw,size_comp,size_fw)))


#Hampton 2006b #They normalized
code_name='Hampton2006b_Plank1'
x_intra=c(0.52,0.44,0.92,0.66,0.57,0.64,0.54)-1 #Autocorrelation coefficient
x_inter=c(0.23,0.09,0.23,-0.06,-0.11,-0.16,-0.22,-0.27,-0.12,-0.14)
val_signif=NA
x_comp=c(-0.06,-0.22,-0.27,-0.14)
x_fw=c(0.23,0.09,0.23,-0.11,-0.16,-0.12)
size_comp=12
size_fw=30
print(code_name)
tab_answer=rbind(tab_answer,c(code_name,whatwewant(x_intra,x_inter,val_signif,x_comp,x_fw,size_comp,size_fw)))

code_name='Hampton2006b_Plank2'
x_intra=c(0.56,0.53,0.45,0.46,0.64,0.45,0.62,0.62,0.63,0.38,0.13,0.52,0.52)-1
x_inter=c(-0.12,0.09,0.09,-0.05,-0.36,-0.16,-0.22,-0.17,0.14,0.26,0.29,0.15,0.31,-0.09,0.1,-0.27,-0.15,-0.22,0.24,-0.26,0.24,-0.14,-0.13,-0.2,-0.32,-0.12,-0.11,0.17,-0.09,0.09)
val_signif=NA
x_comp=c(-0.12,-0.05,-0.36,-0.16,-0.22,-0.09,-0.27,-0.22,-0.26,0.24,-0.32,-0.11,-0.09)
x_fw=c(0.09,0.09,-0.17,0.14,0.26,0.29,0.15,0.31,0.1,0.24,-0.15,-0.14,-0.13,-0.2,0.17,0.09, -0.12)
size_comp=46
size_fw=110
print(code_name)
tab_answer=rbind(tab_answer,c(code_name,whatwewant(x_intra,x_inter,val_signif,x_comp,x_fw,size_comp,size_fw)))
##########################################END WARNING AUTOCORRELATION COEFFICIENT
}#END of 1==0
#Huber&Gaedke 2006
code_name='Huber2006_Phyto'
x_intra=c(0.44,0.74,0.48,0.68,0.47,0.57,0.61,0.6,0.67,0.62)-1
x_inter=c(-0.15,-0.26,-0.09,-0.16,-0.15,-0.06,-0.12,-0.15,-0.02,-0.1,-0.04,-0.05,-0.15,-0.03,-0.03,-0.13,-0.07,-0.12)
val_signif=NA
x_comp=x_inter
x_fw=NA
size_comp=NA
size_fw=NA
print(code_name)
tab_answer=rbind(tab_answer,c(code_name,whatwewant(x_intra,x_inter,val_signif,x_comp,x_fw,size_comp,size_fw)))

code_name='Huber2006_Ciliate'
x_intra=c(0.42,0.44,0.46,0.61,0.42,0.59,0.33,0.75,0.55,0.33)-1
x_inter=c(-0.13,-0.15,-0.08,-0.12,-0.09,-0.18,-0.15,-0.04,-0.1,-0.08,-0.06,-0.17,-0.06)
val_signif=NA
x_comp=x_inter
x_fw=NA
size_comp=NA
size_fw=NA
print(code_name)
tab_answer=rbind(tab_answer,c(code_name,whatwewant(x_intra,x_inter,val_signif,x_comp,x_fw,size_comp,size_fw)))

#Hampton 2008: no values given directly, and I'm not measuring, thanks

#Scheef 2012: same as above; 41% positive interactions in the zooplankton communities (11x11, but some zoo are omnivorous)

#Scheef 2013: worse than above, no tables

#WARNING: so called AUTOREGRESSIVE COEFFICIENT: for me, it's an intraspecies interaction
#Griffiths 2015
code_name='Griffiths2015_Phyto1'
x_intra=c(0,0.2,0.19,0,0.18,0.27,0.18)-1
x_inter=c(-0.28,-0.12,-0.31,0.09)
val_signif=NA
x_comp=x_inter
x_fw=NA
size_comp=NA
size_fw=NA
print(code_name)
tab_answer=rbind(tab_answer,c(code_name,whatwewant(x_intra,x_inter,val_signif,x_comp,x_fw,size_comp,size_fw)))

code_name='Griffiths2015_Phyto2'
x_intra=c(0,0,0,0,0.18,0.4,0.36)-1
x_inter=c(-0.14,0.1,-0.18)
val_signif=NA
x_comp=x_inter
x_fw=NA
size_comp=NA
size_fw=NA
print(code_name)
tab_answer=rbind(tab_answer,c(code_name,whatwewant(x_intra,x_inter,val_signif,x_comp,x_fw,size_comp,size_fw)))
#END OF WARNING FOR AUTOREGRESSIVE COEFFICIENT

#Beisner 2003: no intra (da fuck?)

#Carpenter 2005: no value given

#Duffy 2007: no value given

#Hall 2009: not applicable, this paper is about parasitism in a single species

#Ives 1999
code_name='Ives1999_Zoo1'
x_intra=c(-0.59,-0.19,-0.28,-0.07,-0.27,-0.14,-0.1,-0.37,1)
x_inter=c(-0.19,-0.05,-0.16,-0.06,0.12,-0.13,-0.18,-0.22,-0.4,-0.13,-0.05,-0.14,0.15,-0.11)
val_signif=NA
x_comp=c(-0.19,-0.05,-0.16,-0.18,-0.13,-0.22,-0.14)
x_fw=c(-0.06,0.12,0.15,-0.11,-0.05,-0.4,-0.13)
size_comp=36
size_fw=36
print(code_name)
tab_answer=rbind(tab_answer,c(code_name,whatwewant(x_intra,x_inter,val_signif,x_comp,x_fw,size_comp,size_fw)))

code_name='Ives1999_Zoo2'
x_intra=c(-0.45,0,-0.25,-0.13,-0.27,-0.14,-0.07,-0.39,1)
x_inter=c(-0.03,-0.2,-0.16,-0.24,-0.09,-0.03,-0.03,0.07,-0.12,-0.16,-0.19,-0.02,-0.57,-0.02,-0.11,0.12,-0.21,-0.02)
val_signif=NA
x_comp=c(-0.03,-0.2,-0.16,-0.24,-0.03,-0.03,-0.12,-0.16,-0.19,-0.02,-0.11)
x_fw=c(-0.09,0.07,-0.58,-0.02,-0.12,-0.21,-0.02)
size_comp=36
size_fw=36
print(code_name)
tab_answer=rbind(tab_answer,c(code_name,whatwewant(x_intra,x_inter,val_signif,x_comp,x_fw,size_comp,size_fw)))

#Lindegren 2009
code_name='Lindegren2009_Fish'
x_intra=c(0.9,0.87,0.67)-1
x_inter=c(0,-0.1,-0.06,0,0.23,-0.09)
val_signif=NA
x_comp=c(0,-0.1)
x_fw=c(0,-0.06,0.23,-0.09)
size_comp=2
size_fw=4
print(code_name)
tab_answer=rbind(tab_answer,c(code_name,whatwewant(x_intra,x_inter,val_signif,x_comp,x_fw,size_comp,size_fw)))

#Vik 2008, finally some terrestrial stuff
code_name='Vik2008_LynxHare'
x_intra=c(-0.31,-.25)
x_inter=c(0.23,-0.46)
val_signif=NA
x_comp=NA
x_fw=x_inter
size_comp=NA
size_fw=NA
print(code_name)
tab_answer=rbind(tab_answer,c(code_name,whatwewant(x_intra,x_inter,val_signif,x_comp,x_fw,size_comp,size_fw)))

#Ward 2010: not applicable, same populations of sea lions

#Yamamura 2006: insects, just taking into account first lag
code_name="Yamamura2006_Insects"
x_intra=c(0.502,0.-0.025,0.353)-1
x_inter=c(0.115,-0.005,0.648,0.274,0.305,-0.198)
#val_signif=c(0.648,0.274)
val_signif=NA
x_comp=x_inter
x_fw=NA
size_comp=NA
size_fw=NA
print(code_name)
tab_answer=rbind(tab_answer,c(code_name,whatwewant(x_intra,x_inter,val_signif,x_comp,x_fw,size_comp,size_fw)))
colnames(tab_answer)=c("Code","Mean Intra","Sd intra","Mean Inter","Sd Inter","Mean Inter with 0","Sd inter0","Prop val neg","Prop signif","Dimension","Mean Comp.","Sd comp","Mean Food web","Sd food web")
write.table(tab_answer,file='essai_answer.txt',sep=";",row.names=F,col.names=T)

#Mutshinda 2009: no way to retrieve the interspecific coefficients, we just know they are very low compared to intra and evt

#Comparing
pdf("comparaison_ratio_no_code.pdf",width=12)
par(mfrow=c(1,2),xpd=NA)
cod_cod=rep("cyan",dim(tab_answer)[1])
cod_cod[as.numeric(tab_answer[,"Dimension"])>=4]="blue"
cod_cod[as.numeric(tab_answer[,"Dimension"])>=8]="darkblue"

symbol=rep(21,dim(tab_answer)[1])
symbol[as.numeric(tab_answer[,"Prop signif"])>=0.2]=22
symbol[as.numeric(tab_answer[,"Prop signif"])>0.3]=24

plot(as.numeric(tab_answer[,2])/as.numeric(tab_answer[,4]),t="p",pch=symbol,bg=cod_cod,col="black",cex=2,xlab="",ylab="Intra/inter")
title('Only signif')

plot(as.numeric(tab_answer[,2])/as.numeric(tab_answer[,6]),t="p",pch=symbol,bg=cod_cod,col="black",cex=2,xlab="",ylab="Intra/inter")
lines(1:dim(tab_answer)[1],rep(10,dim(tab_answer)[1]),col="black")
legend("topleft",pch=c(16,16,16,21,22,24),leg=c('Dim<4','Dim<9','Dim>=9','% signif<0.2','% signif<=0.3','% signif>0.3'),col=c("cyan","blue","darkblue","black","black",'black'),bty='n')
title('Adding 0')
dev.off()

pdf("comparaison_ratio_code.pdf",width=14,height=12)
par(mfrow=c(1,2),xpd=NA)
cod_cod=rep("cyan",dim(tab_answer)[1])
cod_cod[as.numeric(tab_answer[,"Dimension"])>=4]="blue"
cod_cod[as.numeric(tab_answer[,"Dimension"])>=8]="darkblue"

symbol=rep(21,dim(tab_answer)[1])
symbol[as.numeric(tab_answer[,"Prop signif"])>=0.2]=22
symbol[as.numeric(tab_answer[,"Prop signif"])>0.3]=24

plot(as.numeric(tab_answer[,2])/as.numeric(tab_answer[,4]),t="p",pch=symbol,bg=cod_cod,col="black",cex=2,xlab="",ylab="Intra/inter")
text(1:dim(tab_answer)[1],as.numeric(tab_answer[,2])/as.numeric(tab_answer[,4])-0.1,tab_answer[,1])
title('Only signif')

plot(as.numeric(tab_answer[,2])/as.numeric(tab_answer[,6]),t="p",pch=symbol,bg=cod_cod,col="black",cex=2,xlab="",ylab="Intra/inter")
lines(1:dim(tab_answer)[1],rep(10,dim(tab_answer)[1]),col="black")
text(1:dim(tab_answer)[1],as.numeric(tab_answer[,2])/as.numeric(tab_answer[,6])-2.5,tab_answer[,1])
legend("topleft",pch=c(16,16,16,21,22,24),leg=c('Dim<4','Dim<9','Dim>=9','% signif<0.2','% signif<=0.3','% signif>0.3'),col=c("cyan","blue","darkblue","black","black",'black'),bty='n')
title('Adding 0')
dev.off()

pdf("comparaison_ratio_code_log.pdf",width=10,height=8)
par(mfrow=c(1,1),xpd=NA,mar=c(1,4.5,1,4.5))
cod_cod=rep("cyan",dim(tab_answer)[1])
cod_cod[as.numeric(tab_answer[,"Dimension"])>=4]="blue"
cod_cod[as.numeric(tab_answer[,"Dimension"])>=8]="darkblue"

symbol=rep(21,dim(tab_answer)[1])
symbol[as.numeric(tab_answer[,"Prop signif"])>=0.2]=22
symbol[as.numeric(tab_answer[,"Prop signif"])>0.3]=24

plot(log10(as.numeric(tab_answer[,2])/as.numeric(tab_answer[,6])),t="p",pch=symbol,bg=cod_cod,col="black",cex=2,xlab="",ylab="|intra|/|inter|",yaxt="n",ylim=c(0,2),cex.lab=1.5)
lines(1:dim(tab_answer)[1],rep(1,dim(tab_answer)[1]),col="black",lty=2,lwd=2)
axis(2,at=c(0,log10(5),1,log10(50),2),lab=c("1","5","10","50","100"))
names_1=tab_answer[,1]
names_1[10]=""
names_1[9]=""
text(1:dim(tab_answer)[1],log10(as.numeric(tab_answer[,2])/as.numeric(tab_answer[,6]))-.05,names_1)
text(10,log10(as.numeric(tab_answer[10,2])/as.numeric(tab_answer[10,6]))-.05,tab_answer[10,1],pos=4)
text(9,log10(as.numeric(tab_answer[9,2])/as.numeric(tab_answer[9,6]))+.1,tab_answer[10,1],pos=1)
legend("bottomleft",pch=c(16,16,16,21,22,24),leg=c('Dim<4','Dim<9','Dim>=9','% signif<20%','% signif<=30%','% signif>30%'),col=c("cyan","blue","darkblue","black","black",'black'),bty='n')
dev.off()

