graphics.off()
rm(list=ls())

source("~/Documents/Plankton/REPHY_littoral/script/matrix_MAR_clean.r")

whatwewant=function(x_intra,x_inter){
	dimension=length(x_intra)
	x_inter=x_inter[x_inter!=0]
	prop_signif=sum(c(x_inter,x_intra)!=0)/(dimension^2)
	val_signif=c(x_inter,rep(0,dimension*(dimension-1)-length(x_inter)))
	val=c(mean(abs(x_intra)),sd(abs(x_intra)),mean(abs(x_inter)),sd(abs(x_inter)),mean(abs(val_signif)),sd(abs(val_signif)),dimension,prop_signif)
}


tab_answer=matrix(NA,nrow=1,ncol=9)
colnames(tab_answer)=c("Code","MeanIntra","SdIntra","MeanInter","SdInter","MeanSignif","SdSignif","Dimension","Prop signif")
code_name=c('Hampton2006a_biweekly','Hampton2006a_growing','Hampton2006b_full','Hampton2006b_simple','Griffiths2015_Phyto1','Griffiths2015_Phyto2','Huber2006_Phyto','Huber2006_Ciliate','Ives1999_Zoo1','Ives1999_Zoo2','Ives2003_Plank1','Ives2003_Plank2','Ives2003_Plank3','Klug2000_Phyto','Klug2000_Zoo','Klug2001_TaxoAlgae','Klug2001_MorphoAlgae','Lindegren2009_Fish','Vik2008_LynxHare','Yamamura2006_Insects')

for(c in 1:length(code_name)){
plou=as.matrix(read.csv(paste(code_name[c],'.csv',sep=""),sep=";",dec=".",header=T,row.names=1))
if(diag(plou)[1]>0){
	x_intra=diag(plou)-1
}else{
	x_intra=diag(plou)
}
nodiag=plou
diag(nodiag)=NA
nodiag=c(nodiag)
nodiag=nodiag[!is.na(nodiag)]
x_inter=nodiag
print(code_name[c])
tab_answer=rbind(tab_answer,c(code_name[c],whatwewant(x_intra,x_inter)))
}

#Barraquand2018
code_name=c(code_name,"Barraquand2018_Teychan","Barraquand2018_B7")
c=c+1
load("~/Documents/Plankton/script_propre/Fred_master/PhytoplanktonArcachon_MultivariateTimeSeriesAnalysis/MARSS_results/Teychan_physics_pencen.RData")
plou=clean_matrix(fit_log)
x_intra=diag(plou)
nodiag=plou
diag(nodiag)=NA
nodiag=c(nodiag)
nodiag=nodiag[!is.na(nodiag)]
x_inter=nodiag
print(code_name[c])
tab_answer=rbind(tab_answer,c(code_name[c],whatwewant(x_intra,x_inter)))

c=c+1
load("~/Documents/Plankton/script_propre/Fred_master/PhytoplanktonArcachon_MultivariateTimeSeriesAnalysis/MARSS_results/B7_physics_pencen.RData")
plou=clean_matrix(fit_log)
x_intra=diag(plou)
nodiag=plou
diag(nodiag)=NA
nodiag=c(nodiag)
nodiag=nodiag[!is.na(nodiag)]
x_inter=nodiag
print(code_name[c])
tab_answer=rbind(tab_answer,c(code_name[c],whatwewant(x_intra,x_inter)))

tab_answer=tab_answer[-which(is.na(tab_answer[,1])),]

#Alphabetical order
id=order(code_name)
tab_answer=tab_answer[id,]
code_name=code_name[id]

#Chronological order
years=unlist(regmatches(code_name, gregexpr("[[:digit:]]{4}", code_name)))
id=order(years)
tab_answer=tab_answer[id,]
code_name=code_name[id]

#names_1=paste('[',1:length(code_name),']',sep='')

xlab_try=rep(NA,length(code_name))
names_1=rep(NA,length(code_name))
aletter=c('a','b','c')
xlab_try[1]=1
names_1[1]="1a"
al=1
for(i in 2:length(code_name)){
	beg1=strsplit(code_name[i-1],"_")[[1]][1]
	beg2=strsplit(code_name[i],"_")[[1]][1]
	if(beg1==beg2){
		al=al+1
		xlab_try[i]=xlab_try[i-1]	
	}else{
		al=1
		xlab_try[i]=xlab_try[i-1]+1
	}
	names_1[i]=paste(as.character(xlab_try[i]),aletter[al],sep="")
}

#names_1=code_name

xlab_try=c(xlab_try,rep(xlab_try[length(xlab_try)]+1,10))

#This Study
groupe=c("BZ","MO","AR","SU")
other=c('Br','Ol','Ar','Me')
for (gg in 1:length(groupe)){
        g=groupe[gg]
        if(g=="BZ"){
                option_lieu=c("Men er Roue","Loscolo","Croisic")
        }else if(g=="MO"){
                option_lieu=c("LEperon","Cornard","Auger")
        }else if(g=="SU"){
                option_lieu=c("Antoine","Lazaret")
        }else if(g=="AR"){
                option_lieu=c("Teychan","B7")
        }
        for (ll in 1:length(option_lieu)){
		c=c+1
	#	names_1=c(names_1,paste(substr(g,1,1),as.character(ll),sep=""))
		names_1=c(names_1,paste(other[gg],as.character(ll),sep=""))
		code_name=c(code_name,paste('ThisStudy','_',option_lieu[ll],sep=""))
        	f1=paste("~/Documents/Plankton/REPHY_littoral/data/analyse_MAR/",g,"/site_specific/",option_lieu[ll],"_pencen_null_regular_common_",g,".RData",sep="")
                load(f1)
		plou=clean_matrix(fit_log)
		x_intra=diag(plou)
		nodiag=plou
		diag(nodiag)=NA
		nodiag=c(nodiag)
		nodiag=nodiag[!is.na(nodiag)]
		x_inter=nodiag
		print(code_name[c])
		tab_answer=rbind(tab_answer,c(code_name[c],whatwewant(x_intra,x_inter)))
	}
}
#Comparing
pdf("~/Documents/Plankton/REPHY_littoral/article/graphe/comparaison_ratio_code_nolog_cleaner.pdf",width=18,height=8)
par(mfrow=c(1,2),xpd=NA,mar=c(4,4.5,1,0.5))
cod_cod=rep("cyan",dim(tab_answer)[1])
cod_cod[as.numeric(tab_answer[,"Dimension"])>=4]="blue"
cod_cod[as.numeric(tab_answer[,"Dimension"])>=8]="darkblue"

symbol=rep(21,dim(tab_answer)[1])
symbol[as.numeric(tab_answer[,"Prop signif"])>0.3]=22
symbol[as.numeric(tab_answer[,"Prop signif"])>0.5]=24

#Choosing another color and symbol for Our study
#cod_cod[23:32]="darkorchid"
#symbol[23:32]=23

plot(xlab_try,(as.numeric(tab_answer[,"MeanIntra"])/as.numeric(tab_answer[,"MeanInter"])),t="p",pch=symbol,bg=cod_cod,col="black",cex=2,xlab="",ylab="|intra|/|inter|",cex.lab=1.5,xlim=c(0.85,max(xlab_try)+0.5),xaxt='n',cex.axis=1.5)
mtext("Chronological order",side=1,line=2.5,cex=1.5)
#lines(1:max(xlab_try),rep(1,max(xlab_try)),col="black",lty=2,lwd=2)
#axis(2,at=c(0,log10(5),1,log10(50),2),lab=c("1","5","10","50","100"))
#names_1=tab_answer[,1]
#text(1:dim(tab_answer)[1],(as.numeric(tab_answer[,"MeanIntra"])/as.numeric(tab_answer[,"MeanInter"]))-.05,names_1)
text(xlab_try[c(1:23,26:27,29:32)],as.numeric(tab_answer[c(1:23,26:27,29:32),"MeanIntra"])/as.numeric(tab_answer[c(1:23,26:27,29:32),"MeanInter"]),names_1[c(1:23,26:27,29:32)],pos=c(2,4),cex=1.5)
text(xlab_try[c(24,25,28)],c(0,0,-0.4)+as.numeric(tab_answer[c(24,25,28),"MeanIntra"])/as.numeric(tab_answer[c(24,25,28),"MeanInter"]),names_1[c(24,25,28)],pos=c(2,4),cex=1.5)
legend(x=1,y=10.5,pch=c(16,16,16,21,22,24),leg=c('Dim<4','Dim<9','Dim>=9','density<=0.3','density<=0.5','density >0.5'),col=c("cyan","blue","darkblue","black","black",'black'),bty='n',cex=1.5,lty=NA,lwd=2)

#Second plot
xx=as.numeric(tab_answer[,"Prop signif"])
yy=as.numeric(tab_answer[,"MeanIntra"])/as.numeric(tab_answer[,"MeanInter"])
plot(xx,yy,pch=16,col="black",ylab="",xlab="",cex=2,cex.axis=1.5,xlim=c(-0.0,1))
text(xx,yy,names_1,pos=c(2,4),cex=1.5)
mtext("Density",side=1,line=2.5,cex=1.5)

dev.off()
#WITH ONLY DIM >9
#Comparing
pdf("~/Documents/Plankton/REPHY_littoral/article/graphe/comparaison_ratio_code_nolog_cleaner_dim9.pdf",width=18,height=8)
id=which(as.numeric(tab_answer[,'Dimension'])>=9,)
tab_answer_bis=tab_answer[id,]
par(mfrow=c(1,2),xpd=NA,mar=c(4,4.5,1,0.5))
cod_cod=rep("cyan",dim(tab_answer_bis)[1])
cod_cod[as.numeric(tab_answer_bis[,"Prop signif"])>=0.25]="blue"
cod_cod[as.numeric(tab_answer_bis[,"Prop signif"])>=0.35]="darkblue"

symbol=rep(21,dim(tab_answer_bis)[1])

#Choosing another color and symbol for Our study
#cod_cod[23:32]="darkorchid"
#symbol[23:32]=23

plot(xlab_try[id],(as.numeric(tab_answer_bis[,"MeanIntra"])/as.numeric(tab_answer_bis[,"MeanInter"])),t="p",pch=symbol,bg=cod_cod,col="black",cex=2,xlab="",ylab="|intra|/|inter|",cex.lab=1.5,xaxt='n',cex.axis=1.5)
mtext("Chronological order",side=1,line=2.5,cex=1.5)
#lines(1:max(xlab_try),rep(1,max(xlab_try)),col="black",lty=2,lwd=2)
#axis(2,at=c(0,log10(5),1,log10(50),2),lab=c("1","5","10","50","100"))
#names_1=tab_answer_bis[,1]
#names_1=names_1[id]
#text(xlab_try[id],(as.numeric(tab_answer_bis[,"MeanIntra"])/as.numeric(tab_answer_bis[,"MeanInter"]))-.05,names_1)
#text(xlab_try[c(1:23,26:27,29:32)],as.numeric(tab_answer[c(1:23,26:27,29:32),"MeanIntra"])/as.numeric(tab_answer[c(1:23,26:27,29:32),"MeanInter"]),names_1[c(1:23,26:27,29:32)],pos=c(2,4),cex=1.5)
#text(xlab_try[c(24,25,28)],c(0,0,-0.4)+as.numeric(tab_answer[c(24,25,28),"MeanIntra"])/as.numeric(tab_answer[c(24,25,28),"MeanInter"]),names_1[c(24,25,28)],pos=c(2,4),cex=1.5)
legend("topleft",pch=c(16,16,16,21,22,24),leg=c('Dim<4','Dim<9','Dim>=9','density<=0.3','density<=0.5','density >0.5'),col=c("cyan","blue","darkblue","black","black",'black'),bty='n',cex=1.5,lty=NA,lwd=2)

#Second plot
xx=as.numeric(tab_answer_bis[,"Prop signif"])
yy=as.numeric(tab_answer_bis[,"MeanIntra"])/as.numeric(tab_answer_bis[,"MeanInter"])
plot(xx,yy,pch=16,ylab="",xlab="",cex=2,cex.axis=1.5,xlim=c(0.15,0.55),col=cod_cod)
text(xx,yy,names_1,pos=c(2,4),cex=1.5)
mtext("Density",side=1,line=2.5,cex=1.5)

dev.off()

#Comparing
pdf("~/Documents/Plankton/REPHY_littoral/article/graphe/comparaison_ratio_code_log_cleaner_allwith0.pdf",width=10,height=8)
par(mfrow=c(1,1),xpd=NA,mar=c(3,4.5,1,4.5))
cod_cod=rep("cyan",dim(tab_answer)[1])
cod_cod[as.numeric(tab_answer[,"Dimension"])>=4]="blue"
cod_cod[as.numeric(tab_answer[,"Dimension"])>=8]="darkblue"

symbol=rep(21,dim(tab_answer)[1])
symbol[as.numeric(tab_answer[,"Prop signif"])>0.3]=22
symbol[as.numeric(tab_answer[,"Prop signif"])>0.5]=24

#Choosing another color and symbol for Our study
#cod_cod[23:32]="darkorchid"
#symbol[23:32]=23

plot(xlab_try,log10(as.numeric(tab_answer[,"MeanIntra"])/as.numeric(tab_answer[,"MeanSignif"])),t="p",pch=symbol,bg=cod_cod,col="black",cex=2,xlab="",ylab="|intra|/|inter|",yaxt="n",ylim=c(-0.1,2),cex.lab=1.5,xaxt="n",xlim=c(0.9,max(xlab_try)+0.5))
lines(c(0.9,max(xlab_try)+0.5),rep(1,2),col="black",lty=2,lwd=2)
mtext("Chronological order",side=1,line=1.5,cex=1.5)
axis(2,at=c(0,log10(5),1,log10(50),2),lab=c("1","5","10","50","100"),cex.axis=1.5)
#names_1=tab_answer[,1]
#text(1:dim(tab_answer)[1],log10(as.numeric(tab_answer[,"MeanIntra"])/as.numeric(tab_answer[,"MeanSignif"]))-.05,names_1)
id=c(1,2,4:12,14:21)
text(xlab_try[id],log10(as.numeric(tab_answer[id,"MeanIntra"])/as.numeric(tab_answer[id,"MeanSignif"])),names_1[id],pos=c(2,4),cex=1.5)
id=3
text(xlab_try[id]-0.1,log10(as.numeric(tab_answer[id,"MeanIntra"])/as.numeric(tab_answer[id,"MeanSignif"])),names_1[id],pos=c(2,4),cex=1.5)
id=13
text(xlab_try[id],0.05+log10(as.numeric(tab_answer[id,"MeanIntra"])/as.numeric(tab_answer[id,"MeanSignif"])),names_1[id],pos=c(2,4),cex=1.5)


text(xlab_try[31:32],0.05+log10(as.numeric(tab_answer[31:32,"MeanIntra"])/as.numeric(tab_answer[31:32,"MeanSignif"])),names_1[31:32],pos=c(2,4),cex=1.5)
text(xlab_try[29:30]-0.055,log10(as.numeric(tab_answer[29:30,"MeanIntra"])/as.numeric(tab_answer[29:30,"MeanSignif"])),names_1[29:30],pos=2,cex=1.5)
text(xlab_try[23],log10(as.numeric(tab_answer[23,"MeanIntra"])/as.numeric(tab_answer[23,"MeanSignif"])),names_1[23],pos=4,cex=1.5)
text(xlab_try[22],log10(as.numeric(tab_answer[22,"MeanIntra"])/as.numeric(tab_answer[22,"MeanSignif"])),names_1[22],pos=2,cex=1.5)
id=order(log10(as.numeric(tab_answer[24:28,"MeanIntra"])/as.numeric(tab_answer[24:28,"MeanSignif"])),decreasing=T)
id=id+23
for(i in 1:length(id)){
	ylab_try=log10(as.numeric(tab_answer[id[i],"MeanIntra"])/as.numeric(tab_answer[id[i],"MeanSignif"]))
	text(xlab_try[id[i]]-0.2,ylab_try-i*0.075,names_1[id[i]],pos=2,cex=1.5)
	arrows(xlab_try[id[i]]-0.25,ylab_try-i*0.075,xlab_try[id[i]],ylab_try,length=0)
}
legend("bottomleft",pch=c(16,16,16,21,22,24),leg=c('Dim<4','Dim<9','Dim>=9','density<=0.3','density<=0.5','density>0.5'),col=c("cyan","blue","darkblue","black","black",'black'),bty='n',cex=1.5,lty=NA,lwd=2)
dev.off()

